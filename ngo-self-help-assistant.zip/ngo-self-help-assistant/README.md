# 阿助（A-Zhu）— NGO AI 方案顧問

NGO 前線同事的工作麻煩，很多根本不用走到共創卡——一句提示詞、或一個現成 Skill/Expert 就能搞掂。阿助先接住請求，判斷清楚再分流，能教就教、能配對就配對，真的複雜才建議創建共創卡。

## 類型

Agent 型（單個 AI 專家）

## 核心功能

1. **四維分流判斷**：從輸入類型、步驟複雜度、頻率規模、一致性需求四個維度判斷任務屬性
2. **提示詞教學**：任務能靠對話解決時，即場給出定制 WorkBuddy 提示詞範本並引導試用
3. **現有資源配對**：本地 Skill/Expert + marketplace 三軌並行搜索，命中即推薦（Expert 優先）
4. **共創卡轉介**：確認資源耗盡、確屬複雜新需求，才轉介 ngo-challenge-advisor 共創卡流程

## 使用示例

- 「我最近工作上遇到個麻煩，唔知可唔可以直接用 WorkBuddy 搞掂。」
- 「我每個禮拜都要重複做一啲好花時間嘅整理工作，有冇辦法簡化下？」
- 「幫我睇下寫一份活動通知，到底要整個專門工具，定係直接問 WorkBuddy 就得？」

## 附帶 Skill

- `ngo-self-help-triage`：完整六階段分流流程（Phase 0–3b/c），含 NGO 對照表（14 條）、純 Prompt 效果判斷、教學路徑三層把關，參考資料存於 `skills/ngo-self-help-triage/references/`

## 打包分享

```bash
zip -r ngo-self-help-assistant.zip ngo-self-help-assistant/
```
