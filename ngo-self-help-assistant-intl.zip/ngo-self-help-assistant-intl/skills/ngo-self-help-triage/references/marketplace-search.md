# 內置 Skill 搜索流程（不依賴 find-skills 插件）

阿助查 Skill 時用呢份流程，**唔需要目標機器裝咗 `find-skills` 插件**。好多用戶系統本身冇裝 find-skills，所以阿助自帶呢份搜索能力。

## 核心原則

**按「任務匹配度」搜索，唔按「ngo 名稱」搜索。** 睇個 Skill 嘅 `description` 描述嘅能力有冇覆蓋到當前任務，唔係睇佢個名有冇「ngo」字眼。搜索關鍵詞由「任務要做啲乜」拆解，**唔會攞「ngo」當搜索詞**。例：「搭活動官網」→ 拆成 website/builder、event/報名、form/表單，唔係搵「ngo website」。

## 第 1 級：本地 skills 目錄（最可靠，主力）

掃 `~/.workbuddy/skills/*/SKILL.md`，逐個讀 frontmatter 嘅 `name` + `description`，用「任務關鍵詞」匹配 description 描述嘅能力。

**呢度係 NGO 技能最可靠嘅來源**——`ngo-event-websites`、`ngo-playbook-demo-design` 等 NGO 技能都喺本地 `~/.workbuddy/skills/` 度，唔喺 SkillHub 網絡市場上。

## 第 2 級：available-resources.md（阿助自帶清單）

按能力描述匹配，唔按名字。阿助 Phase 3 Step 1 已經讀過呢份，呢度係交叉確認。

## 第 3 級：SkillHub API（網絡兜底，沒有就算了）

```
curl "https://lightmake.site/api/v1/search?q=<任務關鍵詞>&limit=10"
```

過濾 `score < 0.05` 嘅無關結果。**SkillHub 係開發者生態，NGO 垂直場景覆蓋弱，搜唔到就算了，唔再向 Vercel / ClawHub 等其他渠道層層升級。**

## 關鍵詞拆解（至少 2–3 組）

- 核心動詞 + 場景
- 資料類型 + 輸出格式
- 痛點 + 功能

---

SkillHub 搜索接口源自 find-skills（MIT License，Copyright 2026 Kyle）。
