---
name: ngo-voice-report
version: 1.2.3
description: This skill should be used when guiding NGO users inside WorkBuddy to turn interview audio, transcripts, report templates, and reference materials into privacy-conscious social-work report drafts, especially for Cantonese/广东话 interviews. It uses pre-set WorkBuddy-first processing assumptions, asks clickable intake questions including required output format selection (HTML/PDF/Word), helps users upload the right materials, produces transcript review files, structured report drafts, missing-information lists, review checklists, and requested exportable outputs while preserving supplied template layout as much as possible.
agent_created: true
---

# NGO Voice Report

## Purpose

Use WorkBuddy as the full workflow surface for NGO interview-to-report work. Guide users through uploading interview materials, choosing template and language options, reviewing transcript content, and producing report drafts with concrete output files.

Prioritize non-technical NGO usage: clickable choices, clear upload prompts, stable report structure, template-aware formatting, missing-information flags, and human review.

## Default Principles

Apply these defaults:

1. Ask for materials and report requirements, not technical setup.
2. Use clickable option questions whenever the answer set is predictable.
3. Keep first-round intake concise (4 core questions + 1 conditional privacy-mode question only when audio is provided).
4. Use free-text questions only for open-ended case context or special requirements.
5. Use the pre-set WorkBuddy-first capability plan before doing any ad-hoc search or setup.
6. Do not repeatedly search the user's filesystem, discover tools, install dependencies, or ask about plugins unless the pre-set plan cannot process the provided material.
7. Treat every generated report as a draft requiring professional review.
8. Never block all output just because no institution template is available.
9. Use the bundled default report schema when no template is provided.
10. Preserve supplied template format and layout as much as WorkBuddy can.
11. Mark unknown or unsupported information as `未能從訪談確認`.
12. Produce concrete files when there is enough input to generate a report.
13. Never leave a long transcription in an open-ended waiting state; provide progress, a checkpoint file, and clickable next-step options.

## Pre-Set Capability Plan

Use this plan at the start of each run to save time:

1. Treat WorkBuddy as the default processing environment.
2. Use uploaded files and explicitly provided paths only; do not browse Downloads/Desktop or search broad folders for candidate files unless the user asks.
3. Use WorkBuddy's available audio/transcript reading capability first.
4. If an audio file cannot be transcribed in the current session, ask for an uploaded transcript or pasted transcript.
5. Use the bundled default report schema when no institution template is provided.
6. Use `scripts/evaluate_transcript_accuracy.py` only when the user provides a reference transcript and wants accuracy evaluation.
7. Do not install speech-to-text plugins, document converters, or local dependencies during normal NGO user flow.
8. If a required capability is unavailable, explain the missing capability in business language and ask for the next best material instead.

## Intake Flow

Start with a short explanation:

```text
可以。我会在 WorkBuddy 里一步步帮你处理：先收集录音/转写、模板和报告要求，再输出转写、报告草稿、待确认事项和可下载文件。
```

Then use clickable option questions. Do not paste a long text menu and ask the user to type answers manually.

### First Clickable Question Set

Ask these questions with clickable options:

1. What material can be provided now?
   - Upload audio
   - Upload transcript
   - Upload both
   - Paste short transcript

2. Is there an organization report template?
   - Word/DOCX template
   - PDF or old report
   - Screenshot/reference only
   - No template, use default

3. What output format does the user need? This question is required before report generation. Use multi-select so the user can pick any combination of HTML / Word / PDF; do not offer a combined "Multiple formats" option.

4. What language should the report use?
   - Traditional Chinese
   - Simplified Chinese
   - English
   - Same as interview

5. Enable privacy mode? This question should only be asked when the user selected "Upload audio" or "Upload both" in Q1. Skip it for transcript-only or paste-short-transcript workflows.
   - Yes, anonymize sensitive information: transcribe locally with WorkBuddy ASR first, then run HaS local anonymization before any cloud LLM call. Sensitive entities (names, phone numbers, addresses, emails, ID numbers, institution names, case numbers, medical info) are replaced with semantic tags. A mapping file is saved locally for optional restoration afterward.
   - No, proceed normally: use the raw transcript for report generation.

Ask follow-up questions only when needed:

- interview language when audio is provided: Cantonese / Mandarin / English / Mixed or unsure;
- case context and report purpose;
- service area or organization type;
- risk assessment or follow-up requirements;
- retention preference for generated workspace files;
- reference transcript or expected report for quality evaluation.

Output format defaults:

- If the user has not answered the output-format question, stop and ask it instead of assuming.
- Default clickable choices must include `HTML preview`, `PDF`, and `Word / DOCX` with multi-select enabled.
- Produce the exact combination the user selected; do not infer or add formats they did not pick.

## Processing Rules

Use this processing order:

1. If the user provides a transcript, use it as the primary source and mark it as user-provided.
2. If the user provides audio, transcribe or extract transcript using WorkBuddy's available capabilities.
3. Do not spend the user's time searching for speech-to-text plugins or installing dependencies during the normal flow.
4. If audio cannot be transcribed in the current session, ask for a transcript instead of pretending transcription succeeded.
5. Preserve important Cantonese meaning when the interview is Cantonese.
6. Produce final reports in formal Traditional Chinese for Hong Kong NGO scenarios unless the user chooses another language.

### Privacy Mode Processing (when user selected "Yes, anonymize sensitive information")

When privacy mode is enabled, insert an anonymization step between WorkBuddy local ASR transcription and cloud LLM report generation:

1. After WorkBuddy completes local ASR transcription, save the raw transcript as `voice-to-report-transcript-raw.txt` (local only, never used for cloud calls).

2. Load `@skill:has-anonymizer` and run local anonymization on the transcript:

   ```bash
   {HaS_SKILL_DIR}/scripts/has.sh text hide \
     --type "人名" \
     --type "电话号码" \
     --type "地址" \
     --type "邮箱" \
     --type "身份证号" \
     --type "机构名称" \
     --type "案件编号" \
     --type "医疗信息" \
     --file voice-to-report-transcript.txt \
     --output voice-to-report-transcript-anonymized.txt \
     --mapping-output voice-to-report-mapping.json
   ```

3. Key rules for privacy mode:
   - The **mapping file** (`voice-to-report-mapping.json`) stays local and is NEVER sent to any cloud service.
   - The raw transcript (`voice-to-report-transcript-raw.txt`) is internal only; do not present it in chat or upload it.
   - When sending anonymized text to the cloud LLM for report generation, prepend the HaS tag-format explanation (per has-anonymizer skill convention) so the model preserves semantic tags.

4. **BEFORE report generation**（在生成报告之前）, show the anonymization result summary and offer restoration as a clickable question:
   - Show a brief summary: how many entities were masked, which types (e.g. "3 个人名已匿名化：Alex → &lt;person name[1]&gt;，Ms. Wong → &lt;person name[2]&gt;，Ms. Lee → &lt;person name[3]&gt;")。
   - Then ask:
     - Restore sensitive information now: run `has text restore` locally to replace semantic tags with real names in the transcript, then generate ONE report with real names. Restoration is local only, mapping file stays on device.
     - Keep anonymized: proceed to generate the report with semantic tags as-is. Mapping file remains for later use.
   - **Only generate ONE report** — either restored or anonymized, not both. Do not generate first then ask.
   - This question must be answered before proceeding to cloud report generation.

5. Mapping file storage warning to user:
   > ⚠️ `voice-to-report-mapping.json` 包含敏感信息映射（如 `人名[1]` → 真实姓名），请妥善保管，使用完毕后建议删除。

6. If HaS model is not yet downloaded (first-time use):
   - Guide the user through the install steps listed in the has-anonymizer skill.
   - The text model is 639 MB; one-time download only.
   - Do not proceed to cloud report generation until anonymization succeeds.

7. Do not skip the output format question (Q3) in privacy mode; report output format selection is still required.

## Long Transcription Handling

Audio transcription may take longer than a normal response window. Do not leave the user seeing only a message like “transcription is still running” with no next step.

Before starting transcription:

1. Acknowledge the template and audio material received.
2. Explain that transcription may take time for longer recordings.
3. Create or update `voice-to-report-progress.md` in the workspace with the current status.

Progress states:

```text
material_received
transcribing_audio
anonymizing  （仅隐私模式：本地 HaS 匿名化运行中）
transcript_ready
generating_report
report_ready
needs_user_input
failed_with_next_steps
```

If transcription is still running or progress is uncertain after one normal attempt, stop waiting silently and ask a clickable next-step question:

- Continue waiting: keep the transcription task running or retry later.
- Upload transcript: user provides an existing transcript to proceed immediately.
- Use partial transcript: proceed only if partial text exists and clearly mark limitations.
- Stop for now: save progress and wait for the user to return.

If the current environment cannot transcribe the audio, set progress to `needs_user_input` and ask for a transcript or pasted excerpt. Do not install plugins or dependencies during the normal NGO flow.

Continue report generation only after a transcript or acceptable transcript substitute exists.

## Report Field Structure

Convert the transcript into a stable field structure before rendering the final report.

Default template fields:

- basic_information — （一）基本資料
- contact_records — （二）聯絡次數
- process_record_and_analysis — （三）過程記錄及分析
- case_progress_analysis — （四）個案進展分析
- plan_and_recommendations — （五）計劃／建議
- review — （六）檢討
- missing_information — 待確認事項
- social_worker_review — 社工覆核欄

Rules:

- Do not invent facts.
- Separate transcript-supported facts from professional interpretation.
- Flag risk content cautiously.
- Put unsupported fields in the missing-information section.
- Include a review section in every report.

## Template and Format Mode

Choose output mode by available template:

```text
Institution DOCX template provided
→ Use DOCX as the primary output.
→ Fill mapped fields while preserving layout, tables, heading hierarchy, fixed wording, field order, review/signature blocks, and headers/footers as much as possible.

PDF / screenshot / old report provided
→ Use it as a visual reference.
→ Recreate the closest practical structure in DOCX/HTML/Markdown.
→ Explain that exact one-to-one formatting requires an editable DOCX template.

No template provided
→ Use assets/default-report-template/default-report-schema.json.
→ Render a stable default report draft.
```

Never return an empty result because the institution template is missing.

For default-template outputs, include this notice:

```text
使用預設模板生成，請由社工審核後再採用。
```

## Output Files

When enough input exists to generate a report, write files into the current workspace according to the user's selected output format.

Required support files:

1. `voice-to-report-transcript.md` or `.txt`
2. `voice-to-report-review-checklist.md`
3. `voice-to-report-progress.md` when transcription or report generation is long-running
4. `voice-to-report-accuracy-report.md` when a reference answer is provided
5. `voice-to-report-mapping.json` when privacy mode is enabled (local only, never cloud-uploaded)
6. `voice-to-report-transcript-raw.txt` when privacy mode is enabled (local only, internal reference)
7. `voice-to-report-transcript-anonymized.txt` when privacy mode is enabled (used for cloud report generation)

Requested report outputs:

- HTML selected → create `voice-to-report-output-report.html`.
- Word / DOCX selected → create `voice-to-report-output-report.docx` when possible.
- PDF selected → generate `voice-to-report-output-report.pdf` using **Playwright** (Node.js, already installed in `~/.workbuddy/binaries/node/workspace/node_modules/playwright`). Recipe: `chromium.launch({headless:true})` → `page.goto(fileUrl)` → `page.pdf({format:'A4', margin:{top:'20mm',bottom:'20mm',left:'15mm',right:'15mm'}, printBackground:true})`. Do NOT use bare Chrome headless (GPU crash in sandbox) or wkhtmltopdf/weasyprint (missing native deps). If Playwright is unavailable, fall back to HTML + state PDF limitation.
- Multiple formats selected → produce the selected combination. If not specified, ask a follow-up; if the user is unavailable, default to HTML + Word and state PDF availability/limitations.

Audit copy:

- Keep `voice-to-report-output-report.md` as an internal/editable audit copy unless the user only wants a single clean deliverable and explicitly asks not to create extra files.

Output priority:

- Put DOCX first when template fidelity is the user's main concern.
- Put HTML first when quick preview is the user's main concern.
- Put PDF first only when the user explicitly chooses PDF and conversion succeeded.
- Never assume the output format silently; ask the HTML/PDF/Word question before report generation.

Present generated files to the user after completion.

## Validation Before Final Delivery

Before presenting final output, check that:

1. Uploaded material was read successfully.
2. Transcript or transcript substitute exists.
3. The user selected an output format from HTML/PDF/Word/multiple formats, or a clear fallback was agreed.
4. Report draft exists in the requested format where possible.
5. Unknown fields use `未能從訪談確認`.
6. Missing-information section exists.
7. Human-review section exists.
8. Long-running transcription did not end in an indefinite waiting state; progress and next-step options were provided when needed.
9. Template mode is stated clearly.
10. Output format limitations are stated when PDF or layout conversion cannot be fully preserved.

## References

Load these references as needed:

- `references/workbuddy-guided-flow.md` for clickable intake and WorkBuddy-first workflow.
- `references/template-output.md` for template mapping, output formats, and layout preservation.
- `references/privacy-and-review.md` for sensitive-material handling and human review wording.

## Bundled Resources

Use these bundled resources:

- `assets/default-report-template/default-report-schema.json`: default report structure when no institution template is provided.
- `scripts/evaluate_transcript_accuracy.py`: optional offline comparison when the user provides a reference transcript.

## Pitfalls

- Do not start report generation before asking the output-format question. Use multi-select with `HTML preview`, `PDF`, and `Word / DOCX` as clickable options; do NOT offer a combined "Multiple formats" option.
- Do not treat Markdown as the user's main requested output unless they explicitly ask for an editable/audit format.
- Do not silently generate every format just because the workflow can; match the user's selected output and explain any unavailable conversion.
- Do not offer privacy mode when the user provides a transcript-only or paste-short-transcript workflow (only audio-based intake triggers the privacy mode question).
- Never send `voice-to-report-mapping.json` to any cloud service; restoration is always local.
- Do not proceed to cloud report generation in privacy mode until HaS anonymization completes successfully. If the HaS model is not installed, guide the user through setup first.
- Do NOT generate the report first and then ask about restoration, causing two copies of the report to be produced. Always ask about restoration BEFORE report generation, so only one report is generated.
- After generating any report file (HTML / PDF / DOCX), **always run a post-generation quality check** before presenting to the user. Scan for: U+FFFD replacement characters (garbled CJK), unmatched brackets/punctuation, broken symbols (e.g. `／` → `??`), and any obviously corrupted text segments. When in privacy mode, also verify: (a) anonymized version has HaS tags but no real names, (b) restored version has zero HaS tags remaining and real names appear in correct count (should match original tag count). Fix any issues found, regenerate the output file, and only then present it. Do NOT skip this step — LLM output with mixed encodings or clipboard corruption can silently produce broken characters.
- When restoring HaS tags in HTML output: the tags in the file use full entity paths and are HTML-escaped (e.g. `&lt;人名[1].姓名.全名&gt;` or `&lt;person name[1].personal.name&gt;`), NOT the bare mapping key format (`<人名[1].姓名.全名>`). Always inspect the actual output file to find the exact tag format used, then build the replacement mapping from that — never assume the mapping.json key strings will match directly. Same applies to PDF/DOCX: the tag format depends on how the report was generated, not on how HaS wrote the mapping.
- **HaS mapping.json value format**: Real HaS output stores values as **lists** (e.g. `{"<人名[1].姓名.全名>": ["Alex"]}`), not plain strings. When restoring, always check `isinstance(value, list)` and extract `value[0]` for the real name. The manual mapping from previous tests used plain strings — this is NOT what live HaS produces.
- **Tag language depends on --type**: Using `--type "人名"` produces Chinese tags `<人名[N].姓名.全名>`; using `--type "person name"` produces English tags `<person name[N].personal.name>`. The restore script must read mapping keys dynamically — never hardcode tag patterns or assume a specific language format.

## Final Response Requirements

When finishing a report task, include:

1. Materials used.
2. Transcript source: uploaded transcript, audio-derived transcript, or user-provided text.
3. Template mode: institution template, visual reference, or bundled default template.
4. Output format mode: what the user requested among HTML/PDF/Word, what was generated, and any PDF/layout limitations.
5. Main report files.
6. Missing-information and review reminder.
7. Known limitations.
