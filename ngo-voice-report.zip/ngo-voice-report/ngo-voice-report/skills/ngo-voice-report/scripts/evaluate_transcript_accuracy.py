#!/usr/bin/env python3
"""Evaluate ASR transcript against a reference answer.

Computes character error rate (CER) and word/token error rate (WER-like) using
simple dynamic-programming edit distance. Works offline and does not upload data.
"""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any, Dict, List


def normalize_text(text: str) -> str:
    text = text.strip().lower()
    text = re.sub(r"[\s\u3000]+", "", text)
    text = re.sub(r"[，。！？、,.!?;；:：\"'“”‘’（）()\[\]{}<>《》\-—_…]", "", text)
    return text


def tokenize_words(text: str) -> List[str]:
    # For Chinese/Cantonese, fall back to character tokens if whitespace tokenization is sparse.
    stripped = text.strip()
    words = [w for w in re.split(r"\s+", stripped) if w]
    if len(words) <= 1:
        return list(normalize_text(text))
    return [normalize_text(w) for w in words if normalize_text(w)]


def edit_distance(a: List[str], b: List[str]) -> int:
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        curr = [i] + [0] * len(b)
        for j, cb in enumerate(b, 1):
            cost = 0 if ca == cb else 1
            curr[j] = min(prev[j] + 1, curr[j - 1] + 1, prev[j - 1] + cost)
        prev = curr
    return prev[-1]


def score(reference: str, hypothesis: str) -> Dict[str, Any]:
    ref_chars = list(normalize_text(reference))
    hyp_chars = list(normalize_text(hypothesis))
    ref_words = tokenize_words(reference)
    hyp_words = tokenize_words(hypothesis)

    char_edits = edit_distance(ref_chars, hyp_chars)
    word_edits = edit_distance(ref_words, hyp_words)
    cer = char_edits / max(1, len(ref_chars))
    wer = word_edits / max(1, len(ref_words))
    return {
        "schema_version": "1.0",
        "reference_chars": len(ref_chars),
        "hypothesis_chars": len(hyp_chars),
        "char_edits": char_edits,
        "cer": round(cer, 4),
        "reference_tokens": len(ref_words),
        "hypothesis_tokens": len(hyp_words),
        "token_edits": word_edits,
        "wer_like": round(wer, 4),
        "note": "For Chinese/Cantonese without spaces, WER-like falls back to character tokens; CER is the primary metric.",
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--reference", required=True, help="Reference transcript text file")
    parser.add_argument("--hypothesis", required=True, help="ASR transcript text file or JSON containing a top-level text or transcript field")
    parser.add_argument("--output", help="Output JSON path")
    args = parser.parse_args()

    reference = Path(args.reference).read_text(encoding="utf-8")
    hyp_path = Path(args.hypothesis)
    hyp_raw = hyp_path.read_text(encoding="utf-8")
    try:
        data = json.loads(hyp_raw)
        hypothesis = data.get("text") or data.get("transcript") or hyp_raw
    except json.JSONDecodeError:
        hypothesis = hyp_raw

    result = score(reference, hypothesis)
    text = json.dumps(result, ensure_ascii=False, indent=2)
    if args.output:
        Path(args.output).write_text(text, encoding="utf-8")
    else:
        print(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
