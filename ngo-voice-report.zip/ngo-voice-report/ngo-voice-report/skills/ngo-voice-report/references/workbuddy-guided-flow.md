# WorkBuddy-Guided Voice-to-Report Flow

## Goal

Run the NGO voice-to-report workflow inside WorkBuddy from intake to final report files. Keep the user experience non-technical and material-driven.

## Pre-Set Capability Plan

Use this plan before any ad-hoc searching or setup:

1. Work inside WorkBuddy by default.
2. Use user-uploaded files and explicitly provided paths only.
3. Do not search Downloads/Desktop/broad folders for candidate audio or templates unless the user asks.
4. Do not install speech-to-text plugins, document converters, or local dependencies during normal NGO flow.
5. If WorkBuddy can read/transcribe the uploaded audio, use it.
6. If transcription may take a long time, create or update `voice-to-report-progress.md` and provide next-step choices instead of waiting indefinitely.
7. If audio transcription is unavailable, ask for a transcript or pasted excerpt.
8. If no template is provided, use the bundled default report schema.
9. If a reference transcript is provided, use the bundled accuracy script.

## Intake Principles

Ask for materials, not setup.

Use clickable option questions for predictable choices. Keep each question concise, with 2-4 options and a free-text fallback for edge cases.

Useful materials:

1. Interview audio: WAV, MP3, M4A, or other common audio format.
2. Existing transcript: TXT, Markdown, DOCX, or pasted text.
3. Report template: DOCX preferred; PDF/screenshots/old report as reference; default template if none.
4. Report language: Traditional Chinese by default for Hong Kong NGO scenarios.
5. Interview language: Cantonese, Mandarin, English, or mixed.
6. Case context: service type, report purpose, participant role, urgency or risk concerns.
7. Reference answer: expected transcript or expected report, if quality evaluation is requested.

## First Clickable Question Set

Present these as selectable UI options.

Question 1: What material can be provided now?

- Upload audio: user will upload an interview recording.
- Upload transcript: user already has a transcript file.
- Upload both: user can provide audio and transcript.
- Paste short transcript: user will paste a short sample.

Question 2: Is there an organization report template?

- Word/DOCX template: best for template-aligned output.
- PDF or old report: use as reference; DOCX can be requested later.
- Screenshot/reference only: use for approximate structure.
- No template, use default: continue with the bundled default template.

Question 3: What output format does the user need? Ask this before report generation. Use multi-select so the user can pick any combination.

- HTML preview: produce an in-app reviewable HTML report.
- Word / DOCX: produce an editable Word report.
- PDF: produce a PDF only when conversion is reliable; otherwise state the limitation and offer HTML or DOCX.

Question 4: What language should the report use?

- Traditional Chinese: default for Hong Kong NGO scenarios.
- Simplified Chinese: use simplified output.
- English: use English output.
- Same as interview: match the source material.

Ask interview language only when audio is provided:

- Cantonese: preserve Cantonese meaning and produce formal written output.
- Mandarin: use Mandarin handling.
- English: use English handling.
- Mixed / unsure: preserve mixed-language context and flag uncertainties.

Question 5 (only when audio is provided): Enable privacy mode?

- Yes, anonymize sensitive information: after WorkBuddy local ASR transcription, run HaS local anonymization before any cloud LLM call. Sensitive entities are replaced with semantic tags; a mapping file is saved locally for optional restoration.
- No, proceed normally: use the raw transcript for report generation.

## Processing Decision Tree

```text
Transcript provided
→ use transcript directly
→ optionally clean transcript
→ generate report fields
→ render report files.

Audio provided
→ acknowledge that transcription may take time
→ create or update `voice-to-report-progress.md`
→ transcribe using available WorkBuddy capability
→ save transcript as `voice-to-report-transcript.md`

   Privacy mode enabled (only asked when audio is provided)
   → save raw transcript as `voice-to-report-transcript-raw.txt` (local only)
   → load @skill:has-anonymizer
   → run `has text hide` with types: 人名, 电话号码, 地址, 邮箱, 身份证号, 机构名称, 案件编号, 医疗信息
   → save `voice-to-report-mapping.json` (local only, never uploaded)
   → use anonymized transcript for all subsequent steps
   → prepend HaS tag-format explanation when sending to cloud LLM

   Privacy mode not enabled
   → use raw transcript for report generation

→ generate report fields
→ render report files.

Audio transcription takes too long
→ do not keep waiting silently
→ update `voice-to-report-progress.md`
→ ask a clickable next-step question: continue waiting, upload transcript, use partial transcript, or stop for now.

Audio cannot be transcribed
→ ask for a transcript or pasted excerpt
→ do not search for plugins or install dependencies during normal flow
→ do not pretend transcription succeeded.

Editable DOCX template provided
→ map report fields to the template
→ preserve layout as much as possible
→ output DOCX plus preview/fallback files.

PDF/screenshot/old report provided
→ use as visual reference
→ recreate the closest practical structure
→ state layout limitations.

No template provided
→ use bundled default report schema
→ clearly label as preset-template draft.
```

## Output Format and Layout Rules

Preserve supplied template format and layout as much as possible.

- DOCX template: use DOCX as the primary output; preserve tables, headings, fixed text, field labels, section order, review/signature blocks, and headers/footers where possible.
- PDF/screenshot/old report: use as a visual reference; recreate the closest practical structure, but explain that exact layout requires editable DOCX.
- No template: use the bundled default schema and keep stable sections and tables.

Do not flatten a table-based report template into a paragraph-only report unless technically impossible.

## Output Files

Generate support files whenever applicable:

- `voice-to-report-transcript.md`
- `voice-to-report-review-checklist.md`
- `voice-to-report-progress.md` when transcription or report generation is long-running
- `voice-to-report-accuracy-report.md` when testing accuracy with a reference answer
- `voice-to-report-transcript-raw.txt` when privacy mode is enabled (local only)
- `voice-to-report-transcript-anonymized.txt` when privacy mode is enabled (cloud-safe)
- `voice-to-report-mapping.json` when privacy mode is enabled (local only, never uploaded)

Generate report outputs only in the user's selected format:

- HTML selected → `voice-to-report-output-report.html`
- Word / DOCX selected → `voice-to-report-output-report.docx`
- PDF selected → `voice-to-report-output-report.pdf` only after reliable conversion succeeds
- Keep `voice-to-report-output-report.md` as an editable/audit copy unless the user explicitly requests a single clean deliverable

Never assume output format. Ask the HTML/PDF/Word question before generating a report.

## Default Template Requirement

No institution template must never mean no output.

When no template exists, produce a default-template draft titled `第一次個案面談過程報告` with these sections:

1. （一）基本資料
2. （二）聯絡次數
3. （三）過程記錄及分析
4. （四）個案進展分析
5. （五）計劃／建議
6. （六）檢討
7. 待確認事項
8. 社工覆核欄

Default label:

```text
使用預設模板生成，請由社工審核後再採用。
```

## Review Rules

Always include human review before treating a report as usable.

Flag:

- unclear speaker identity;
- missing dates or case identifiers;
- risk content requiring urgent professional review;
- unsupported assumptions;
- fields filled with `未能從訪談確認`;
- transcription uncertainty.
