# Sensitive Material and Human Review

## Scope

NGO interview recordings and reports may contain sensitive case information. Treat all generated outputs as drafts and all uploaded material as user-provided sensitive content.

## User-Facing Privacy Wording

Prefer concise wording:

```text
请上传匿名或已获授权处理的材料。我会只围绕你提供的资料生成转写、报告草稿和待确认事项。
```

If the user asks about strict confidentiality, clarify the operating surface:

```text
这个流程会在 WorkBuddy 对话和当前工作空间内处理你上传的资料。若机构规定资料不能进入任何外部工具，请先确认合规边界，再上传真实个案材料。
```

## Sensitive Data Handling

Avoid unnecessary exposure of:

- names;
- addresses;
- phone numbers;
- identity numbers;
- health status;
- family conflict details;
- financial details;
- full transcript excerpts in summaries;
- full report contents in logs or status messages.

Prefer using file outputs for full content and short summaries in chat.

## Privacy Mode (HaS Integration)

When the user enables privacy mode during intake (only available for audio-based workflows):

### Pipeline

```
Upload audio → WorkBuddy local ASR transcription (audio never leaves device)
  → HaS local anonymization (names, phones, addresses, emails, IDs,
     institution names, case numbers, medical info → semantic tags)
  → Anonymized text sent to WB server for report generation
  → Optional local restoration via mapping file
```

### User-Facing Wording

When privacy mode is offered:

```
启用隐私模式后：
- 语音在本地转写（音频不离开你的电脑）
- 敏感信息（人名/电话/地址/邮箱/身份证号/机构名称/案件编号/医疗信息）
  在本地用 HaS 匿名化替换为语义标签后再生成报告
- 匿名化产生的 mapping 文件仅保存在你的电脑上，不会上传
- 生成报告后你可以选择在本地还原敏感信息

HaS 文本模型约 639 MB，首次使用需下载。下载一次后所有后续访谈均可复用。
```

### Anonymization Scope

Default entity types to strip:

- HaS built-in: `人名`, `电话号码`, `地址`, `邮箱`, `身份证号`
- NGO custom: `机构名称`, `案件编号`, `医疗信息`

Entity types are open-set; additional types can be added per user request.

### Mapping File

- Location: `<workspace>/voice-to-report-mapping.json`
- Contains: `real_value → <EntityType[ID].Category.Attribute>` mappings
- Never sent to any cloud service; restoration is always local
- User warning: `voice-to-report-mapping.json 包含敏感信息映射，请妥善保管，使用完毕后建议删除`

### Restoration

**BEFORE report generation**（在生成报告之前）— show anonymization summary and ask:

1. Display anonymization result: how many entities masked, which types (e.g. "3 个人名已匿名化：Alex → &lt;person name[1]&gt;")
2. Ask via clickable question:
   - Restore now: run `has text restore` locally to replace semantic tags with real names in the transcript → generate ONE report with real names
   - Keep anonymized: proceed to generate report with semantic tags as-is; mapping file saved for later use
3. **Only generate ONE report** — never generate first then ask about restoration, which wastes time producing two copies.

**⚠️ Tag format trap**: When restoring, the HaS tags in the output file may differ from mapping.json keys:
- HTML output: tags are HTML-escaped (`&lt;person name[1].personal.name&gt;`) and use full entity paths with category suffixes (`.personal.name`, `.professional.title`).
- mapping.json keys may use the same full-path format or just base keys.
- **Always inspect the actual output file** to find the exact tag strings before doing replacement — do NOT assume the mapping keys will match directly. Test by scanning the file for all unique tag patterns with a regex like `&lt;person name\[\d+\]\.[^&]*&gt;` (HTML) or `<person name\[\d+\]\.[^>]*>` (plain text).

### First-Time Setup

If HaS is not installed:

1. Follow has-anonymizer skill install steps (brew install llama.cpp + uv, download 639 MB model)
2. Do not proceed to cloud report generation until anonymization succeeds
3. Once installed, the model is reused across all subsequent interview sessions

## Troubleshooting (HaS Runtime)

以下问题在 WorkBuddy sandbox + Apple Silicon 环境下已验证会反复出现：

### 1. Sandbox 阻断进程检测

`sandbox PERMISSION DENIED` — `ps` / `lsof` 在 WorkBuddy sandbox 中无权限。

**症状**：`server_runtime.py` 启动或健康检查时报 `PermissionError`。

**修复**：patch `has_text/server_runtime.py` 中 `_listening_pid()` 和 `_read_process_command()`，对 `PermissionError` / `OSError` 加 try/except 返回 None。

### 2. Apple Silicon GPU 不稳定

M 系列芯片上用 `-ngl 999`（Metal GPU 加速）导致 llama-server 随机崩溃或返回 502。

**修复**：永久使用 CPU-only 模式 `-ngl 0`。性能差距可接受（NER 任务轻量）。

### 3. llama-server /tokenize 返回 502

llama.cpp b10174 的 `/tokenize` 端点与 HaS text 模型不兼容，始终返回 502。

**症状**：client 端无法获取 token 计数。

**修复**：monkey-patch 改用字符估算 `len(text) // 4`（适用于英文为主或中英混合文本）。

### 4. client.py 缺 max_tokens

`has_text/client.py` 的 chat payload 不包含 `max_tokens`，导致第二次请求时 server 崩溃。

**修复**：在 payload 中添加 `"max_tokens": 4096`。

### 5. Python requests Session 与 server 通信不稳定

NER 任务通过 Python `requests.Session` 发请求时，llama-server 间歇性崩溃（尤其是含大段文本的 prompt）。

**症状**：报告生成阶段 receiver 侧 502，server 进程退出。

**fallback**：当 Python client 连续失败时，改用 `curl` 直调 `/v1/chat/completions` 做 NER，已验证稳定。具体步骤：
1. 确保 llama-server 在运行（检查 `--port` 参数）
2. 构造 NER prompt + 转写文本
3. `curl -s http://127.0.0.1:<port>/v1/chat/completions -d '{...}'`
4. 手动解析返回的 entities，写入 mapping.json

## Human Review

Generated reports are drafts.

Required review steps:

1. Review the transcript.
2. Review the generated report.
3. Confirm all uncertain fields.
4. Review risk-related statements manually.
5. Edit before formal use.

Do not mark a report as final automatically.

## Risk Content

When risk, self-harm, family violence, safeguarding, medical, or legal issues appear:

- state only what is supported by the transcript;
- avoid overdiagnosis;
- place urgent uncertainties in the missing-information section;
- recommend professional review and organization procedures;
- keep wording cautious.

## Retention

Ask the user whether generated intermediate files should be kept in the workspace or deleted after delivery when the matter is sensitive.
