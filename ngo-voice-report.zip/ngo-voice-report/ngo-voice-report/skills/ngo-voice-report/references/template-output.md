# Template Output and Layout Preservation

## Goal

Generate report files that follow the user's supplied report template as closely as WorkBuddy can. Let content generation fill fields; let deterministic document handling preserve structure and format.

## Template Input Priority

Use this priority:

1. DOCX / Word template.
2. Editable document converted to DOCX.
3. PDF or old report as layout reference.
4. Screenshot as visual reference.
5. Bundled default report schema when no template exists.

## Core Rule

Do not let the report writer freestyle layout when a structured template exists. Extract or infer a field schema, fill the schema, then render into the chosen format.

## DOCX Template Handling

When an editable DOCX template is supplied:

- Use the supplied DOCX as the base document whenever possible.
- Preserve page size, margins, section order, heading hierarchy, tables, merged cells where possible, field labels, fixed wording, signature blocks, review fields, and headers/footers.
- Replace placeholders, mapped content controls, or clearly identified blank fields.
- Keep fixed text unchanged unless the user asks for changes.
- Keep table-based forms as table-based forms.
- Note any layout feature that cannot be preserved.

## PDF / Screenshot / Old Report Handling

When only non-editable reference material is supplied:

- Treat it as a visual/layout reference.
- Recreate the closest practical structure in DOCX/HTML/Markdown.
- Explain that exact one-to-one layout restoration requires an editable DOCX template.
- Preserve visible headings, section order, field labels, and table-like structures where practical.

## Default Template Handling

When no institution template is supplied, use `assets/default-report-template/default-report-schema.json`.

Default document title:

```text
第一次個案面談過程報告
```

Default sections:

1. （一）基本資料
2. （二）聯絡次數
3. （三）過程記錄及分析
4. （四）個案進展分析
5. （五）計劃／建議
6. （六）檢討
7. 待確認事項
8. 社工覆核欄

The process-record section must retain a two-column structure: the interview process / observation on the left and the social worker's assessment / intervention techniques on the right.

Default-template reports must include this label:

```text
使用預設模板生成，請由社工審核後再採用。
```

## Unknown Information Rule

If the transcript or user-provided material does not support a field, fill:

```text
未能從訪談確認
```

Do not invent:

- identity information;
- medical conditions;
- family relationships;
- risk events;
- service history;
- financial status;
- addresses or phone numbers.

## Output Format Selection

Ask the user to choose HTML preview, Word / DOCX, PDF, or multiple formats before rendering. Do not silently apply a priority order as a substitute for user choice.

Apply the selected mode:

1. Word / DOCX: use the supplied editable template as the base when available.
2. HTML preview: render a readable in-app preview with equivalent section structure.
3. PDF: produce only after reliable conversion succeeds; otherwise explain the limitation and offer the selected alternative.
4. Multiple formats: create only the selected combination.
5. Markdown: retain as an editable/audit copy unless the user explicitly requests a single clean deliverable.

## Acceptance Criteria

A report output is acceptable when:

- required fields are present;
- unknown fields are marked rather than invented;
- section order matches the supplied template when provided;
- default section order is used when no template is provided;
- tables remain readable;
- table-based forms remain table-based where possible;
- headings, field labels, fixed wording, and review/signature areas are preserved where possible;
- a human can edit before final use;
- no-template cases still return a draft report rather than an empty result.
